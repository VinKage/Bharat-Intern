package com.example.quizeapp11;

public class QuestionAnswer {
    public static String question[] ={
            "What is the launch date for Chandrayaan 3 mission?",
            "The Chandrayaan 3 mission’s rover is known as",
            "The mission life of the Lander and Rover equal to",
            " Which launcher is used for Chandrayaan-3?",
            "The mission objectives of Chandrayaan-3 is/are ?"
    };

    public static String choices[][] = {
            {"24 July 2023","14 July 2023","13 July 2023","04 July 2023"},
            {"Vikram","Bheem","Pragyaan","Dhruv"},
            {"14 Earth Days","28 Earth Days","10 Earth Days","40 Earth Days"},
            {"GSLV-Mk3","PSLV","Falcon-X","GSLV"},
            {"To demonstrate Rover roving on the moon","To demonstrate a Safe and Soft Landing on Lunar Surface","To conduct in-situ scientific experiments","All of the above"}
    };

    public static String correctAnswers[] = {
            "14 July 2023",
            "Pragyaan",
            "14 Earth Days",
            "GSLV-Mk3",
            "All of the above"
    };
}